use optica
db.clientes.insert([
    {
	_id : ObjectId("62b99047bf2ccd86b1dbe2df"),
        nombre : "Pablo Garcia",
        direccion : {calle : "Gran Via", numero : 100, piso : 1, puerta : 2, ciudad : "Barcelona", zip_code : 08020, Pais : "España"},
        telefono : 555666777,
        email : "pablo@gmail.com",
        fecha_alta : "01/01/2021",
        recomend_name : "Pedro" 
    },
    {
	_id : ObjectId("62b99047bf2ccd86b1dbe2e0"),
        nombre : "Pedro Sanchez",
        direccion : {"calle" : "Paris", "numero" : 5, "piso" : "Atico", "puerta" : "B", "ciudad" : "Barcelona", "zip_code" : 08060, "Pais" : "España"},
        telefono : 555222444,
        email : "pedro@gmail.com",
        fecha_alta : "01/02/2001" 
    },
    {
	_id : ObjectId("62b99047bf2ccd86b1dbe2e1"),
        nombre : "Pepe Nieto"
        direccion : {"calle" : "Bilbao", "numero" : 20, "piso" : 3, "puerta" : 1, "ciudad" : "Barcelona", "zip_code" : 08080, "Pais" : "España"},
        telefono : 555999111,
        email : "pepe@gmail.com",
        fecha_alta : "08/08/2020",
        recomend_name : "Pedro"
    }
])

db.clientes.find().pretty()

db.proveedores.insert([
    {
	_id : ObjectId("62b990c3bf2ccd86b1dbe2e2"),
        nombre : "Jose Perez",
        direccion : {"calle" : "Gran Via", "numero" : 100, "piso" : 1, "puerta" : "2", "ciudad" : "Barcelona", "zip_code" : 08020, "Pais" : "España"},
        telefono : 555444222,
        fax : 555222444,
        nif : "10200500A",
        marcas : [ "Oakley", "Rayban", "Chic"],
    },
    {
	_id : ObjectId("62b990c3bf2ccd86b1dbe2e3"),
        nombre : "Julian Gomez",
        direccion : {"calle" : "Muntaner", "numero" : 2, "piso" : 8, "puerta" : "A", "ciudad" : "Barcelona", "zip_code" : 08010, "Pais" : "España"},
        telefono : 555777999,
        fax : 555999777,
        nif : "20200500B",
        marcas : [ "Adidas"],
    },
    {
	_id : ObjectId("62b990c3bf2ccd86b1dbe2e4"),
        nombre : "Javier Diaz",
        direccion : {"calle" : "Balmes", "numero" : 33, "piso" : 5, "puerta" : "3", "ciudad" : "Barcelona", "zip_code" : 08050, "Pais" : "España"},
        telefono : 555111333,
        fax : 555333111,
        nif : "30200500C",
        marcas : [ "Ouyea"]
    }
])

db.proveedores.find().pretty()

db.gafas.insert([
    {
        marca : "Oakley",
        provider_id : ObjectId("62b990c3bf2ccd86b1dbe2e2"),
        client_id : ObjectId("62b99047bf2ccd86b1dbe2e0"),
        grad_der : 4.5,
        grad_izq : 3.5,
        montura : "pasta",
        color_mont : "negro",
        color_cristal : "transparente",
        precio : 100.5,
        vendedor : "Luis"
    },
    {
        marca : "Rayban",
        provider_id : ObjectId("62b990c3bf2ccd86b1dbe2e2"),
        client_id : ObjectId("62b99047bf2ccd86b1dbe2e0"),
        grad_der : 1,
        grad_izq : 2,
        montura : "flotante",
        color_mont : "gris",
        color_cristal : "oscuro",
        precio : 120.5,
        vendedor : "Ana"
    },
    {
        marca : "Chic",
        provider_id : ObjectId("62b990c3bf2ccd86b1dbe2e2"),
        client_id : ObjectId("62b99047bf2ccd86b1dbe2df"),
        grad_der : 0,
        grad_izq : 0,
        montura : "metalica",
        color_mont : "rojo",
        color_cristal : "azul",
        precio : 160.5,
        vendedor : "Ana"
    },
    {
        marca : "Adidas",
        provider_id : ObjectId("62b990c3bf2ccd86b1dbe2e3"),
        client_id : ObjectId("62b99047bf2ccd86b1dbe2e1"),
        grad_der : 1,
        grad_izq : 1,
        montura : "pasta",
        color_mont : "verde",
        color_cristal : "rojo",
        precio : 180.5,
        vendedor : "Luis"
    },
    {
        marca : "Ouyea",
        provider_id : ObjectId("62b990c3bf2ccd86b1dbe2e4"),
        client_id : ObjectId("62b99047bf2ccd86b1dbe2e1"),
        grad_der : 0,
        grad_izq : 0,
        montura : "pasta",
        color_mont : "negro",
        color_cristal : "verde",
        precio : 80.5,
        vendedor : "Ana"
    }
])

db.gafas.find().pretty()