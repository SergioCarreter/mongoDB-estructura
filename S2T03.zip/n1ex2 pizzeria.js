use pizzeria
db.tiendas.insert([
    {
        nombre: "Sabrosa Madrid",
        direccion : {calle: "Gran Via", numero: 76, piso: "Bajos", ciudad: "Madrid", provincia: "Madrid", zip_code: 28013},
        empleados: [
            { nombre: "Luis", apellidos: "Garcia Garcia", nif: "40200500A", telefono : 555444222, tipo: "Cocinero" },
            { nombre: "Ana", apellidos: "Diaz Diaz", nif: "30100400B", telefono : 555222444, tipo: "Repartidor" }
        ]
    },
    {
        nombre: "Sabrosa Barcelona",
        direccion : {calle: "Muntaner", numero: 2, piso: "Bajos", ciudad: "Barcelona", provincia: "Barcelona", zip_code: 08011},
        empleados: [
            { nombre: "Eva", apellidos: "Perez Perez", nif: "20300600A", telefono : 555777999, tipo: "Cocinero" },
            { nombre: "Toni", apellidos: "Lopez Lopez", nif: "30100500B", telefono : 555999777, tipo: "Repartidor" }
        ]
    },
    {
        nombre: "Sabrosa Sevilla",
        direccion : {calle: "Betis", numero: 6, piso: "Bajos", ciudad: "Sevilla", provincia: "Sevilla", zip_code: 41010},
        empleados: [
            { nombre: "Paco", apellidos: "Ruiz Ruiz", nif: "20300600A", telefono : 555777999, tipo: "Cocinero" },
            { nombre: "Maria", apellidos: "Gomez Gomez", nif: "30100500B", telefono : 555999777, tipo: "Repartidor" }
        ]
    }
])
db.clientes.insert([
    {
        nombre: "Pablo",
        apellidos: "Garcia Garcia",
        direccion: {calle: "Gran Via", numero: 100, piso: 1, puerta: 2, ciudad: "Barcelona", zip_code: 08020, provincia: "Barcelona"},
        telefono: 555666777
    },
    {
        nombre : "Pedro",
        apellidos: "Sanchez Sanchez",
        direccion : {calle: "Paris", numero: 5, piso: "Atico", puerta: "B", ciudad: "Barcelona", zip_code: 08060, provincia: "Barcelona"},
        telefono : 555222444
    },
    {
        nombre : "Pepe",
        apellidos: "Nieto Nieto",
        direccion : {calle: "Hortaleza", numero: 15, piso: 3, puerta: 1, ciudad: "Madrid", zip_code: 28004, provincia: "Madrid"},
        telefono : 555999111
    },
    {
        nombre : "Julio",
        apellidos: "Sanz Sanz",
        direccion : {calle: "Baños", numero: 60, piso: 8, puerta: 2, ciudad: "Sevilla", zip_code: 41002, provincia: "Sevilla"},
        telefono : 555000777
    },
    {
        nombre : "Isa",
        apellidos: "Cano Cano",
        direccion : {calle: "Goya", numero: 101, piso: 2, puerta: 3, ciudad: "Madrid", zip_code: 28009, provincia: "Madrid"},
        telefono : 555111999
    }
])
db.productos.insert([
    {
        nombre: "Coke",
        descripcion: "Coca Cola",
        imagen: "C:/pizzeria/imagenes/bebidas/coke.jpg",
        precio: 1.50,
        tipo_prod: "Bebida"
    },
    {
        nombre: "Agua",
        descripcion: "Agua Fontvella",
        imagen: "C:/pizzeria/imagenes/bebidas/agua.jpg",
        precio: 1.50,
        tipo_prod: "Bebida"
    },
    {
        nombre: "Cerveza",
        descripcion: "Cerveza Mahou",
        imagen: "C:/pizzeria/imagenes/bebidas/cerveza.jpg",
        precio: 2.00,
        tipo_prod: "Bebida"
    },
    {
        nombre: "Pizza Hawaiana",
        descripcion: "pizza mediana hawaiana",
        imagen: "C:/pizzeria/imagenes/pizzas/hawaiana.jpg",
        precio: 7.50,
        tipo_prod: "Pizza",
        cat_pizza: "Regular"
    },
    {
        nombre: "Pizza Barbacoa",
        descripcion: "pizza mediana barbacoa",
        imagen: "C:/pizzeria/imagenes/pizzas/barbacoa.jpg",
        precio: 8.50,
        tipo_prod: "Pizza",
        cat_pizza: "Carnivora"
    },
    {
        nombre: "Pizza Spicy",
        descripcion: "pizza mediana con carne y picante",
        imagen: "C:/pizzeria/imagenes/pizzas/spicy.jpg",
        precio: 9.50,
        tipo_prod: "Pizza",
        cat_pizza: "Carnivora"
    },
    {
        nombre: "Pizza Huerta",
        descripcion: "pizza mediana vegetal",
        imagen: "C:/pizzeria/imagenes/pizzas/huerta.jpg",
        precio: 8.00,
        tipo_prod: "Pizza",
        cat_pizza: "Vegana"
    },
    {
        nombre: "Chesseburger",
        descripcion: "Hamburguesa de Ternera con Queso",
        imagen: "C:/pizzeria/imagenes/burger/chesseburger.jpg",
        precio: 6.00,
        tipo_prod: "Burger"
    },
    {
        nombre: "Hamburguesa Completa",
        descripcion: "Hamburguesa con Ternera, bacon, lechuga, queso, cebolla frita, pepinillos y huevo frito.",
        imagen: "C:/pizzeria/imagenes/burger/completa.jpg",
        precio: 7.50,
        tipo_prod: "Burger"
    }
])
db.pedidos.insert([
    {
        nom_cliente: "Pablo",
        apellidos_cliente: "Garcia Garcia",
        tipo_pedido: "Domicilio",
        fecha_hora: new Date(),
        nom_tienda: "Sabrosa Barcelona",
        nom_repartidor: "Toni", 
        apellidos_repartidor: "Lopez Lopez",
        salida_prod: new Date(),
        productos:[
            {
                nom_prod: "Agua",
                cantidad: 5,
                subtotal: 7.50
            },
            {
                nom_prod: "Pizza Hawaiana",
                cantidad: 2,
                subtotal: 15
            }
        ]
    },
    {
        nom_cliente: "Pedro",
        apellidos_cliente: "Sanchez Sanchez",
        tipo_pedido: "Domicilio",
        fecha_hora: new Date(),
        nom_tienda: "Sabrosa Barcelona",
        nom_repartidor: "Toni", 
        apellidos_repartidor: "Lopez Lopez",
        salida_prod: new Date(),
        productos:[
            {
                nom_prod: "Cerveza",
                cantidad: 6,
                subtotal: 12
            },
            {
                nom_prod: "Hamburguesa Completa",
                cantidad: 2,
                subtotal: 15
            }
        ]
    },
    {
        nom_cliente: "Pablo",
        apellidos_cliente: "Garcia Garcia",
        tipo_pedido: "Domicilio",
        fecha_hora: new Date(),
        nom_tienda: "Sabrosa Barcelona",
        nom_repartidor: "Toni", 
        apellidos_repartidor: "Lopez Lopez",
        salida_prod: new Date(),
        productos:[
            {
                nom_prod: "Coke",
                cantidad: 4,
                subtotal: 6
            },
            {
                nom_prod: "Pizza Spicy",
                cantidad: 2,
                subtotal: 19
            }
        ]
    },
    {
        nom_cliente: "Pepe",
        apellidos_cliente: "Nieto Nieto",
        tipo_pedido: "Domicilio",
        fecha_hora: new Date(),
        nom_tienda: "Sabrosa Madrid",
        nom_repartidor: "Ana", 
        apellidos_repartidor: "Diaz Diaz",
        salida_prod: new Date(),
        productos:[
            {
                nom_prod: "Cerveza",
                cantidad: 6,
                subtotal: 12
            },
            {
                nom_prod: "Pizza Huerta",
                cantidad: 1,
                subtotal: 8
            },
            {
                nom_prod: "Pizza Spicy",
                cantidad: 1,
                subtotal: 9.50
            }
        ]
    },
    {
        nom_cliente: "Julio",
        apellidos_cliente: "Sanz Sanz",
        tipo_pedido: "Domicilio",
        fecha_hora: new Date(),
        nom_tienda: "Sabrosa Sevilla",
        nom_repartidor: "Maria", 
        apellidos_repartidor: "Gomez Gomez",
        salida_prod: new Date(),
        productos:[
            {
                nom_prod: "Coke",
                cantidad: 4,
                subtotal: 6
            },
            {
                nom_prod: "Chesseburger",
                cantidad: 1,
                subtotal: 6
            },
            {
                nom_prod: "Hamburguesa Completa",
                cantidad: 1,
                subtotal: 7.50
            }
        ]
    },
    {
        nom_cliente: "Isa",
        apellidos_cliente: "Cano Cano",
        tipo_pedido: "Domicilio",
        fecha_hora: new Date(),
        nom_tienda: "Sabrosa Madrid",
        nom_repartidor: "Ana", 
        apellidos_repartidor: "Diaz Diaz",
        salida_prod: new Date(),
        productos:[
            {
                nom_prod: "Cerveza",
                cantidad: 4,
                subtotal: 8
            },
            {
                nom_prod: "Pizza Hawaiana",
                cantidad: 1,
                subtotal: 7.5
            },
            {
                nom_prod: "Pizza Spicy",
                cantidad: 1,
                subtotal: 9.50
            }
        ]
    }
])
