use youtube
db.usuarios.insert([
    {
        _id : ObjectId("62b89237bf2ccd86b1dbe2d4"),
        nombre: "Pepe Garcia Garcia",
        password: "1234",
        email: "elpepe@gmail.com",
        date_birth: "01/01/2000",
        sexo: "Male",
        pais: "España",
        zip_code: 08020,
        canales_propios:[ObjectId("62b8960cbf2ccd86b1dbe2d9")],
        canales_suscritos:[ObjectId("62b8960cbf2ccd86b1dbe2d9"),
                            ObjectId("62b8960cbf2ccd86b1dbe2da")],
        playlist:[
            {
                titulo: "Bailes Famosos",
                fecha: "05/01/2020",
                estado: "Publico",
                videos:[
                    ObjectId("62b89880bf2ccd86b1dbe2db"),
                    ObjectId("62b89880bf2ccd86b1dbe2dc"),
                    ObjectId("62b89880bf2ccd86b1dbe2dd"),
                    ObjectId("62b89880bf2ccd86b1dbe2de")
                ]
            }
        ]
    },
    {
        _id : ObjectId("62b89237bf2ccd86b1dbe2d5"),
        nombre: "Ana Diaz Diaz",
        password: "5678",
        email: "anadiaz@gmail.com",
        date_birth: "01/01/2001",
        sexo: "Female",
        pais: "España",
        zip_code: 08030,
        canales_propios:[ObjectId("62b8960cbf2ccd86b1dbe2da")],
        canales_suscritos:[ObjectId("62b8960cbf2ccd86b1dbe2d9"),
                            ObjectId("62b8960cbf2ccd86b1dbe2da")],
        playlist:[
            {
                titulo: "Mis Bailes",
                fecha: "05/05/2020",
                estado: "Publico",
                videos:[
                    ObjectId("62b89880bf2ccd86b1dbe2de")
                ]
            }
        ]
    },
    {
        _id : ObjectId("62b89237bf2ccd86b1dbe2d6"),
        nombre: "Luis Perez Perez",
        password: "0000",
        email: "LuisPerez@gmail.com",
        date_birth: "01/05/2000",
        sexo: "Male",
        pais: "España",
        zip_code: 08040,
        canales_propios:[],
        canales_suscritos:[ObjectId("62b8960cbf2ccd86b1dbe2d9")],
        playlist:[]
    },
    {
        _id : ObjectId("62b89237bf2ccd86b1dbe2d7"),
        nombre: "Eva Sanchez Sanchez",
        password: "1111",
        email: "Eva Sanchez@gmail.com",
        date_birth: "01/08/2000",
        sexo: "Female",
        pais: "España",
        zip_code: 08080,
        canales_propios:[],
        canales_suscritos:[ObjectId("62b8960cbf2ccd86b1dbe2da")],
        playlist:[
            {
                titulo: "Que bailes!",
                fecha: "05/01/2020",
                estado: "Publico",
                videos:[
                    ObjectId("62b89880bf2ccd86b1dbe2db"),
                    ObjectId("62b89880bf2ccd86b1dbe2de")
                ]
            }
        ]
    },
    {
        _id : ObjectId("62b89237bf2ccd86b1dbe2d8"),
        nombre: "Marcos Cano Cano",
        password: "3333",
        email: "marcosCano@gmail.com",
        date_birth: "03/03/2003",
        sexo: "Male",
        pais: "España",
        zip_code: 08000,
        canales_propios:[],
        canales_suscritos:[ObjectId("62b8960cbf2ccd86b1dbe2da")],
        playlist:[]
    }
])
db.usuarios.find().pretty()
db.canales.insert([
    {
        _id : ObjectId("62b8960cbf2ccd86b1dbe2d9"),
        nombre: "Bailes de Pepe",
        descripcion: "Bailes Regionales",
        fecha: "01/01/2020",
        creador: ObjectId("62b89237bf2ccd86b1dbe2d4"),
        users_susc:[ ObjectId("62b89237bf2ccd86b1dbe2d4"), 
                    ObjectId("62b89237bf2ccd86b1dbe2d5"), 
                    ObjectId("62b89237bf2ccd86b1dbe2d6"), 
                    ObjectId("62b89237bf2ccd86b1dbe2d7"), 
                    ObjectId("62b89237bf2ccd86b1dbe2d8")],
        videos: [ObjectId("62b89880bf2ccd86b1dbe2db"),
                ObjectId("62b89880bf2ccd86b1dbe2dc"), 
                ObjectId("62b89880bf2ccd86b1dbe2dd")]
    },
    {
        _id : ObjectId("62b8960cbf2ccd86b1dbe2da"),
        nombre: "Ana y sus Bailes",
        descripcion: "Bailes Regionales",
        fecha: "01/02/2020",
        creador: ObjectId("62b89237bf2ccd86b1dbe2d5"),
        users_susc:[ObjectId("62b89237bf2ccd86b1dbe2d4"), 
                    ObjectId("62b89237bf2ccd86b1dbe2d5"), 
                    ObjectId("62b89237bf2ccd86b1dbe2d7")],
        videos: [ ObjectId("62b89880bf2ccd86b1dbe2de")]
    }
])
db.canales.find().pretty()
db.videos.insert([
    {
        _id: ObjectId("62b89880bf2ccd86b1dbe2db"),
        titulo: "La Jota",
        creador: ObjectId("62b89237bf2ccd86b1dbe2d4"),
        canal: ObjectId("62b8960cbf2ccd86b1dbe2d9"),
        estado: "Publico",
        descripcion: "Baile Maño",
        size: 200,
        file: "laJota.mpg",
        duracion: 26,
        thumbnail: "laJota.jpg",
        n_visual: 500,
        likes: 1,
        dislikes: 0,
        fecha: "02/01/2020",
        etiquetas:[ "El baile", "Cosas de Maños", "Muy aerobico"],
        inter_video: [
            { user:ObjectId("62b89237bf2ccd86b1dbe2d5"), tipo:"like", date: "01/08/2021", time: "12:05:05"},
        ],
        coments: [
            { user: ObjectId("62b89237bf2ccd86b1dbe2d6"), cont: "Ese baile mola", date: "10/01/2020",
                inter_coment: [
                    { user: ObjectId("62b89237bf2ccd86b1dbe2d4"), tipo: "Like"}
                ]
            }
        ]
    },
    {
        _id : ObjectId("62b89880bf2ccd86b1dbe2dc"),
        titulo: "La Lambada",
        creador: ObjectId("62b89237bf2ccd86b1dbe2d4"),
        canal: ObjectId("62b8960cbf2ccd86b1dbe2d9"),
        estado: "Publico",
        descripcion: "Baile brasileiro",
        size: 250,
        file: "laLambada.mpg",
        duracion: 29,
        thumbnail: "laLambada.jpg",
        n_visual: 600,
        likes: 2,
        dislikes: 0,
        fecha: "03/01/2020",
        etiquetas:[ "El baile prohibido", "Cosas de Brasil", "Muy muy aerobico"],
        inter_video: [
            { user: ObjectId("62b89237bf2ccd86b1dbe2d5"), tipo:"like", date: "02/08/2021", time: "01:08:05"},
            { user: ObjectId("62b89237bf2ccd86b1dbe2d7"), tipo:"like", date: "04/08/2021", time: "00:12:10"},
        ],
        coments: [
            { user: ObjectId("62b89237bf2ccd86b1dbe2d6"), cont: "Ese baile mola", date: "10/01/2020", time: "10:10:10",
                inter_coment: [
                    {user: ObjectId("62b89237bf2ccd86b1dbe2d4"), tipo: "Like"}
                ]
            },
            { user: ObjectId("62b89237bf2ccd86b1dbe2d8"), cont: "Desde luego es muy aerobico", date: "11/01/2020", time: "09:00:30",
                inter_coment: [
                    {user: ObjectId("62b89237bf2ccd86b1dbe2d4"), tipo: "Like"}
                ]
            }
        ]
    },
    {
        _id : ObjectId("62b89880bf2ccd86b1dbe2dd"),
        titulo: "El twist",
        creador: ObjectId("62b89237bf2ccd86b1dbe2d4"),
        canal: ObjectId("62b8960cbf2ccd86b1dbe2d9"),
        estado: "Publico",
        descripcion: "Baile Americano",
        size: 200,
        file: "eltwist.mpg",
        duracion: 25,
        thumbnail: "eltwist.jpg",
        n_visual: 30500,
        likes: 0,
        dislikes: 1,
        fecha: "03/01/2020",
        etiquetas:["Baile antiguo", "Cosas de los 60", "Cuidao con los tobillos"],
        inter_video: [
            { user: ObjectId("62b89237bf2ccd86b1dbe2d6"), tipo:"Dislike", date: "06/09/2021", time: "01:31:05"},
        ],
        coments: [
            { user: ObjectId("62b89237bf2ccd86b1dbe2d6"), cont: "Buf, un poco antiguo", date: "12/04/2021", time: "08:33:09",
                inter_coment: [
                    {user: ObjectId("62b89237bf2ccd86b1dbe2d7"), tipo: "Like"}
                ]
            },
        ]

    },
    {
        _id : ObjectId("62b89880bf2ccd86b1dbe2de"),
        titulo: "La conga",
        creador: ObjectId("62b89237bf2ccd86b1dbe2d5"),
        canal: ObjectId("62b8960cbf2ccd86b1dbe2da"),
        estado: "Publico",
        descripcion: "Baile Cubano",
        size: 200,
        file: "laconga.mpg",
        duracion: 25,
        thumbnail: "laconga.jpg",
        n_visual: 210500,
        likes: 2,
        dislikes: 0,
        fecha: "04/01/2020",
        etiquetas:["Baile festivo", "Sabor cubano"],
        inter_video: [
            { user: ObjectId("62b89237bf2ccd86b1dbe2d4"), tipo:"like", date: "08/08/2021", time: "02:05:05"},
            { user: ObjectId("62b89237bf2ccd86b1dbe2d6"), tipo:"like", date: "12/09/2021", time: "00:01:06"},
        ],
        coments: [
            { user: ObjectId("62b89237bf2ccd86b1dbe2d8"), cont: "Gran baile para fiestas", date: "20/02/2021", time: "12:40:09",
                inter_coment: [
                    {user: ObjectId("62b89237bf2ccd86b1dbe2d4"), tipo: "Like"},
                    {user: ObjectId("62b89237bf2ccd86b1dbe2d5"), tipo: "Like"}
                ]
            },
            { user: ObjectId("62b89237bf2ccd86b1dbe2d7"), cont: "Que divertido!", date: "11/03/2021", time: "11:03:20",
                inter_coment: [
                    {user: ObjectId("62b89237bf2ccd86b1dbe2d4"), tipo: "Like"}
                ]
            }
        ]
    }
])
db.videos.find().pretty()




